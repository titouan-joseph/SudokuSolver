echo 'export PATH=$PATH:~/lab7/Sudoku/PIT_sudoku_REVOL_Titouan-Joseph/src' >> ~/.bashrc
